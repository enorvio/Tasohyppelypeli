# Tasohyppelypeli

Kaksiulotteinen tasohyppelypeli, jossa pelaaja liikuttelee hahmoa näppäimistön avulla tavoitteena kerätä pisteitä ja välttää vihollisia.

[Aiheen kuvaus](dokumentaatio/aiheenKuvausJaRakenne.md)

[Tuntikirjanpito](dokumentaatio/tuntikirjanpito.md)

PIT-raportti: https://htmlpreview.github.io/?https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/pit/201606090351/index.html

Checkstyle-raportti: https://htmlpreview.github.io/?https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/site/checkstyle.html

