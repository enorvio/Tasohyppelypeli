/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fi.enorvio.tasohyppelypeli.logiikka;

import fi.enorvio.tasohyppelypeli.logiikka.Kentta;
import fi.enorvio.tasohyppelypeli.logiikka.Pelaaja;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tabby
 */
public class PelaajaTest {

    int[][] laatat = {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1},
    {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
    {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};
    Kentta testiKentta = new Kentta(laatat);
    Pelaaja testiPelaaja = new Pelaaja(testiKentta);

    public PelaajaTest() {
    }

    
    
    @Test
    public void PelaajaEiHyppaaIlmassa() {
        testiPelaaja.setX(1);
        testiPelaaja.setY(1);
        testiPelaaja.hyppaa();
        assertEquals(testiPelaaja.getHyppy(), 0);
    }
    
    @Test
    public void PelaajaKuoleePudotessaanRotkoon() {
        testiKentta.setLaatta(0, 15, 0);
        testiKentta.setLaatta(1, 15, 0);
        testiPelaaja.setX(1);
        testiPelaaja.setY(1);
        while(testiPelaaja.onElossa()) {
            testiPelaaja.liiku();
        }
        assertEquals(testiPelaaja.getY(), 479);
        assertEquals(testiPelaaja.getElamat(), 8);
    }
    
    @Test
    public void PelaajaOsaaTeleportata() {
        testiKentta.luoTeleportti(15, 15, 3, 3);
        testiPelaaja.setX(15*32);
        testiPelaaja.setY(15*32);
        testiPelaaja.liiku();
        assertEquals(testiPelaaja.getX(), 128);
        assertEquals(testiPelaaja.getY(), 96);
        
    }
    
    @Test
    public void PelaajaEiTeleporttaaHetiTakaisin() {
        testiKentta.luoTeleportti(15, 15, 3, 3);
        testiPelaaja.setX(15*32);
        testiPelaaja.setY(15*32);
        for (int i = 0; i < 600; i++) {
            testiPelaaja.liiku();
        }
        assertEquals(testiPelaaja.getX(), 128);
        assertEquals(testiPelaaja.getY(), 448);
        
    }
   
}
