/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fi.enorvio.tasohyppelypeli.logiikka;

/**
 *
 * @author enorvio
 */
public class Teleportti {
    private int alkuX;
    private int alkuY;
    private int loppuX;
    private int loppuY;
    
    public Teleportti(int alkuX, int alkuY, int loppuX, int loppuY) {
        this.alkuX = alkuX;
        this.loppuX = loppuX;
        this.alkuY = alkuY;
        this.loppuY = loppuY;
    }
    
    public int[] getToinenPaa(int x, int y) {
        if (x == this.alkuX && y == this.alkuY) {
            int[] toinenPaa = {this.loppuX * 33, this.loppuY};
            return toinenPaa;
        } else if (x == this.loppuX && y == this.loppuY) {
            int[] toinenPaa = {this.alkuX * 33, this.alkuY};
            return toinenPaa;
        }
        return null;            
    }
}
