**Aihe:**
Kaksiulotteinen tasohyppelypeli. Toteutetaan yksinkertaisehko peli, jossa pelaaja liikuttaa spriteä näppäinkontrolleilla tavoitteena läpäistä kenttiä ja kerätä pisteitä.

**Käyttäjät:**
Pelaaja

**Kaikkien käyttäjien toiminnot:**
* uuden pelin aloittaminen
* spriten liikuttaminen näppäimistön avulla
* pelin lopettaminen

**Luokkakaavio**

![Alt text][id1]

[id1]: https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/luokkakaavio_3.png  

**Sekvenssikaavioita**

![Alt text][id2]

[id2]: https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/sekvenssikaavio1.png  

![Alt text][id3]

[id3]: https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/sekvenssikaavio2.png 

![Alt text][id4]

[id4]: https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/sekvenssikaavio3.png 
