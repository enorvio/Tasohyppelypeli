**Aihe:**
Kaksiulotteinen tasohyppelypeli. Toteutetaan yksinkertaisehko peli, jossa pelaaja liikuttaa spriteä näppäinkontrolleilla tavoitteena läpäistä kenttiä ja kerätä pisteitä.

**Käyttäjät:**
Pelaaja

**Kaikkien käyttäjien toiminnot:**
* uuden pelin aloittaminen
* spriten liikuttaminen näppäimistön avulla
* pelin lopettaminen

**Määrittelyvaiheen luokkakaavio**

![Alt text][id]

[id]: https://github.com/enorvio/Tasohyppelypeli/blob/master/dokumentaatio/luokkakaavio_1.png  
