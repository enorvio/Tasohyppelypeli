### Tuntikirjanpito
Päivä | Tunnit | Kuvaus
--------------- | ----- | ------
17.05.2016 | 2h | Aiheen valinta, repositorion luonti, aihemäärittely, tuntikirjanpidon aloitus.
19.05.2016 | 5h | Loin alustavasti joitain luokkia ja niiden konstruktoreita, luin Swingin dokumentaatiota.
20.05.2016 | 8h | Loin luokat Pelaaja, PeliIkkuna, Kentta ja Peli. Toteutin ensimmäisen version pelaajan liikkumisesta ja pelilogiikasta, mutta en vielä näppäinkontrolleja. Aloitin testien laatimisen. 
21.05.2016 | 4h | En saanut näppäinkontrolleja kytkettyä (toteutettua kuuntelijaa) joten toteutin liikkuvat viholliset. 
23.05.2016 | 8h | Kävin pajassa ja ohjaajan avulla saatiin ratkaistua näppäinkontrolleihin liittyvät ongelmat. 
24.05.2016 | 3h | Tein luokkakaavion ja muokkasin liiku()-metodia.
26.05.2016 | 5h | Refaktoroin sotkuiseksi muodostuneen Pelaaja-luokan luomalla uuden luokan Hahmo, jonka Pelaaja ja Vihollinen perivät. Generoin pit- ja Checkstyle-raportit. Korjasin Checkstyle-raportin ilmoittamat virheet. 
30.5.2016 | 9h | Siistin vähän Vihollinen -luokkaa. Toteutin kenttien lukemisen tekstitiedostosta valmiiksi annetun taulukon sijaan. Toteutin pisteet, niiden keräämisen, niiden laskemisen, hahmon kuolemisen pudotessa kuiluun ja elämien vähenemisen. Tein statuspaneelin joka näyttää elämät ja pisteet. Toteutin kentän läpäisemisen ja automaattisen siirtymisen seuraavaan kenttään. Aloin tehdä graafista käyttöliittymää (alkuvalikko). Kuriositeettina, sain vihollisille ominaisuuden jonka avulla niiden päällä voi matkustaa, eli toimii vähän niin kuin hissi. Tein yhden testin lisää. 
