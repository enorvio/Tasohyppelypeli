# Tasohyppelypeli

Kaksiulotteinen tasohyppelypeli, jossa pelaaja liikuttelee hahmoa näppäimistön avulla tavoitteena kerätä pisteitä ja välttää vihollisia.

[Aiheen kuvaus](dokumentaatio/tuntikirjanpito.md)

[Tuntikirjanpito](dokumentaatio/aiheenKuvausJaRakenne.md)
